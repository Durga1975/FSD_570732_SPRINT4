import { Component } from '@angular/core';

@Component({
  selector: 'app-FSD-list',
  templateUrl: './FSD-list.component.html',
  styleUrls: ['./FSD-list.component.css']
})
export class FSDListComponent {

}


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/