export const employee = [
  {
    id: 1,
    name: 'satya',
    salary: 799,
    address: 'Bangalore'
  },
  {
    id: 2,
    name: 'kini',
    salary: 699,
    address: 'Bangalore'
  },
  {
    id: 3,
    name: ' Standardlay',
    salary: 299,
    address: 'Bangalore'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/